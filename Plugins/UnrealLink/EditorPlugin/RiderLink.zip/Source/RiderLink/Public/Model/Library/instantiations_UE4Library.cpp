#include "instantiations_UE4Library.h"

namespace rd {
template class Polymorphic<ELogVerbosity::Type>;
}
