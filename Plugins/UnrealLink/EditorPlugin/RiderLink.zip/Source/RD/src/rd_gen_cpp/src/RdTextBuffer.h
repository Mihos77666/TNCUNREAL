#ifndef RD_CPP_RDTEXTBUFFER_H
#define RD_CPP_RDTEXTBUFFER_H

namespace rd
{
class RdTextBuffer
{
};
}	 // namespace rd

#endif	  // RD_CPP_RDTEXTBUFFER_H
