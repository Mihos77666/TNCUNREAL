﻿#pragma once

#include "Modules/ModuleInterface.h"

class RIDERSHADERINFO_API FRiderShaderInfoModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
};
